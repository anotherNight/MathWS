1、可以结合oj做题目
http://ac.jobdu.com/hhtproblems.php
2、源码可以和书本一一对应了。
