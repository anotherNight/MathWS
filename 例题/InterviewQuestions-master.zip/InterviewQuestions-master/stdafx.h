// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once
#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <tchar.h>
#include <set>
#include <vector>
#include <iostream>
#include <functional>
using namespace std;



